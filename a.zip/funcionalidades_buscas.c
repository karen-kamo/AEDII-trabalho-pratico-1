/*
Karen Nanamy Kamo - NUSP: 15495932 
Rebeca de Oliveira Silva - NUSP: 11963923
*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#include "structs.h"
#include "ler_arq.h"
#include "escrever_arq.h"
#include "funcionalidades.h"
#include "uteis.h"

/* ================================================================================

******************************FUNCIONALIDADE 2************************************

===================================================================================*/ 

/* Funcionalidades: 

  1. Abrir o arquivo.bin para leitura
  2. Ler o arquivo até o final, registro por registro (Linha por linha)
  3. Caso o registro exista, deve imprimir campo a campo

*/

void buscar_todos_reg_bin(){
  char nomeArqBin[100];
  scanf("%s", nomeArqBin); // leitura do input do usuário

  FILE *arqBin = NULL; // inicializa o ponteiro
  RegistroCabecalho *h = abrir_e_validar_arq_bin(nomeArqBin, &arqBin);
  if (h == NULL) return; // se der errado, só para

  //Enquanto não terminar o arquivo.bin, continue lendo os valores dos registros de dados
  while (check_eof(arqBin)){
    RegistroDado *r = ler_reg_dado_bin(arqBin);

    if (r == NULL){ // se algo deu errado
      break;
    }

    // verificando se o registro está logicamente removido
    // apenas ignora o removido e continua
    if (r->removido == '1'){
      free_reg_dado(r);
      free(r);
      continue;
    } 
    
    imprimir_reg_dado(r);
    
    free_reg_dado(r);
    free(r);
  }

  free_reg_cab(h);
  fclose(arqBin);
}

//===============================================================================================================================//


// Função para buscar o Registro de Cabeçalho
//Não precisava para o trabalho 1
//Usado para debugar o código pelas estudantes 
void buscar_reg_cab_bin(){
  char nomeArqBin[100];
  scanf("%s", nomeArqBin);

  // abrir arquivo binário para leitura
  FILE *arqBin = fopen(nomeArqBin, "rb");
  if (arqBin == NULL) {
    printf("Falha no processamento do arquivo.\n");
    return;
  }

  // mover cursor para o início do arquivo
  fseek(arqBin, 0, SEEK_SET);

  RegistroCabecalho *h = ler_reg_cab_bin(arqBin);
  if (h == NULL) printf("Falha no processamento do arquivo.\n");
  imprimir_reg_cab(h);

  free_reg_cab(h);
  fclose(arqBin);
}

/* ================================================================================

******************************FUNCIONALIDADE 3************************************

===================================================================================*/ 

/* Funcionalidades: 

  1. Abrir o arquivo.bin para leitura
  2. Quantidade de buscas pelo usuário
  3. Quantidade de pares de busca pelo usuário 
  4. Entrada dos valores desejadas pelo usuário
  5. Compara os valores fornecido pelo usuário com os resgistros de dados
  6. Imprime, caso exista
*/
void buscar_reg_filtro(){
  char nomeArqBin[100];
  int quantBusca; 
  int quantPar; // armazena quantos pares o usuário quer
  
  // arrays para guardar os dados que devem ser filtrados
  char nomesCampos[100][500];
  char valoresCampos[100][500];

  scanf("%s %d", nomeArqBin, &quantBusca); // leitura dos inputs do usuário

  FILE *arqBin = NULL; // inicializa o ponteiro
  RegistroCabecalho *h = abrir_e_validar_arq_bin(nomeArqBin, &arqBin);
  if (h == NULL) return; // se der errado, só para

  // loop para buscar de acordo com a quantidade desejada
  for (int i = 0; i < quantBusca; i++){
    scanf("%d", &quantPar); // input de quantos pares vai desejar buscar

    int filtroCod = 0; // flag para saber se codEstacao é um filtro
    int codBuscado = -1; // guardar o codEstacao buscado

    // loop para a quantidade de pares desejadas
    for (int j = 0; j < quantPar; j++){
      scanf("%s", nomesCampos[j]); // lê o nome do campo desajado

      if (strcmp(nomesCampos[j], "nomeEstacao") == 0 ||
          strcmp(nomesCampos[j], "nomeLinha") == 0
      ){
        ScanQuoteString(valoresCampos[j]); // se for string, para ler "" 
      } else {
        scanf("%s", valoresCampos[j]);  // se for int, lê normalmente
      }

      if (strcmp(nomesCampos[j], "codEstacao") == 0){
        filtroCod = 1; // se um dos filtros é pelo codEstacao
        codBuscado = verificar_nulo(valoresCampos[j]); // guardando o codEstacao buscado
      }
    }

    // mover para o byte 17 para buscar nos dados
    fseek(arqBin, 17, SEEK_SET);

    int naoEhInexistente = 0; // para ver se o registro foi printado ou não

    // fazer busca até o final do arquivo
    while (check_eof(arqBin)){
      RegistroDado *r = ler_reg_dado_bin(arqBin);

      if (r == NULL){ // caso falte memória
        break;
      }

      // verificando se o registro está logicamente removido
      // se for removido, apenas ignora e continua
      if (r->removido == '1'){
        free_reg_dado(r);
        free(r);
        continue;
      }
      
      int achou = verificacao_filtros(r, nomesCampos, valoresCampos, quantPar);

      if (achou){
        imprimir_reg_dado(r);
        naoEhInexistente = 1;
      }

      // para verificar se a busca por cod deu certo
      int pararBusca = (filtroCod && r->codEstacao == codBuscado);

      free_reg_dado(r);
      free(r);

      if (pararBusca) break; // se foi encontrado pelo codEstacao e se é igual ao buscado, para
    }

    if (!naoEhInexistente) printf("Registro inexistente.\n");

    // pular linha entre as buscas, menos no final
    if (i < quantBusca - 1) printf("\n");
  }
  
  free_reg_cab(h);
  fclose(arqBin);
}


/* ================================================================================

******************************FUNCIONALIDADE 4************************************

===================================================================================*/ 

/* Funcionalidades: 

  1.Abrir o arquivo.bin para leitura
  2. Calcula o byteoffset apartir do RRN de entrada
  3. Move o ponteiro para a posição desejada
  4. Tratamento de casos de registros removidos

*/
void buscar_reg_RRN(){
  char nomeArqBin[100];
  int rrn;

  // entrada dos dados desejados
  scanf("%s %d", nomeArqBin, &rrn);

  FILE *arqBin = NULL; // inicializa o ponteiro
  RegistroCabecalho *h = abrir_e_validar_arq_bin(nomeArqBin, &arqBin);
  if (h == NULL) return; // se der errado, só para
  
  // verificando se esse RRN existe nos registros
  if (rrn >= h->proxRRN || rrn < 0) {
    printf("Registro inexistente.\n");
    fclose(arqBin);
    return;
  }

  // calculando o byte que deve ser buscado
  int byteOffSet = 80 * rrn + 17;
  fseek(arqBin, byteOffSet, SEEK_SET);

  RegistroDado *r = ler_reg_dado_bin(arqBin);

  // verificando se o registro está logicamente removido
  if (r == NULL || r->removido == '1'){
    printf("Registro inexistente.\n");
  } else {
    imprimir_reg_dado(r);
  }

  free_reg_dado(r);
  free(r);
  free_reg_cab(h);

  fclose(arqBin);
}


/* ================================================================================

******************************FUNCIONALIDADE 6************************************

===================================================================================*/ 

/* Funcionalidades: 

  1. Abrir o arquivo.bin para leitura e status
  2. Quantidade de buscas pelo usuário
  3. Quantidade de pares de busca pelo usuário 
  4. Entrada dos valores desejadas pelo usuário
  5. Verifica se uma das buscas é por codEstacao
  6. Se for, carrega o índice na RAM e busca pelo índice
  7. Se não, faz busca sequencial
  8. Imprime, caso exista
*/
void busca_indexada(){
  char nomeArqBin[100];
  char nomeArqInd[100];
  int quantBusca; 
  int quantPar;
  
  // arrays para guardar os dados que devem ser filtrados
  char nomesCampos[100][500];
  char valoresCampos[100][500];

  scanf("%s %s %d", nomeArqBin, nomeArqInd, &quantBusca); // leitura dos inputs do usuário

  // 1. Abrir o arquivo.bin para leitura e status
  FILE *arqBin = NULL; // inicializa o ponteiro
  RegistroCabecalho *h = abrir_e_validar_arq_bin(nomeArqBin, &arqBin);
  if (h == NULL) return; // se der errado, só para

  // carregando o índice para a RAM
  int nRegistrosIndice = 0; // para guardar quant de regs
  RegistroDadoIndice *listaIndice = carregar_indice_na_memoria(nomeArqInd, &nRegistrosIndice);

  if (listaIndice == NULL){
    free_reg_cab(h);
    fclose(arqBin);
    return; // quer dizer que não tem os regs 
  }

  // 2. Quantidade de buscas pelo usuário
  // loop para buscar de acordo com a quantidade desejada
  for (int i = 0; i < quantBusca; i++){
    scanf("%d", &quantPar); // input de quantos pares vai desejar buscar

    int filtroCod = 0; // flag para saber se codEstacao é um filtro
    int codBuscado = -1; // para guardar o codEstacao buscado

    // 3. Quantidade de pares de busca pelo usuário 
    // loop para a quantidade de pares desejadas
    for (int j = 0; j < quantPar; j++){

      // 4. Entrada dos valores desejadas pelo usuário
      scanf("%s", nomesCampos[j]); // lê o nome do campo desajado

      if (strcmp(nomesCampos[j], "nomeEstacao") == 0 ||
          strcmp(nomesCampos[j], "nomeLinha") == 0
      ) ScanQuoteString(valoresCampos[j]); // se for string, para ler "" 
      else scanf("%s", valoresCampos[j]);  // se for int, lê normalmente

      if (strcmp(nomesCampos[j], "codEstacao") == 0){
        filtroCod = 1; // codEstacao é uma das buscas
        codBuscado = verificar_nulo(valoresCampos[j]); // pega o codEstacao
      }
    }

    // 5. Verifica se uma das buscas é por codEstacao
    if (filtroCod){
      int rrnBuscado = busca_binaria_indice(listaIndice, nRegistrosIndice, codBuscado);

      if (rrnBuscado != -1){
        // verificando se esse RRN existe nos registros
        if (rrnBuscado >= h->proxRRN || rrnBuscado < 0) {
          printf("Registro inexistente.\n");
          if (i < quantBusca - 1) printf("\n"); // pular linha
          continue;
        }

        // calculando o byte que deve ser buscado
        int byteOffSet = 80 * rrnBuscado + 17;
        fseek(arqBin, byteOffSet, SEEK_SET);

        RegistroDado *r = ler_reg_dado_bin(arqBin);

        // verificando se o registro está logicamente removido
        if (r == NULL) printf("Registro inexistente.\n"); // se algo deu errado
        else if (r->removido == '1'){
          printf("Registro inexistente.\n");
          free_reg_dado(r);
          free(r);
        } else {
          // verificando nos outros campos buscados
          if (verificacao_filtros(r, nomesCampos, valoresCampos, quantPar)) imprimir_reg_dado(r);
          else printf("Registro inexistente.\n");

          free_reg_dado(r);
          free(r);
        }
      } else printf("Registro inexistente.\n"); // não tem registro

    } else { // 7. Se não, faz busca sequencial
      // mover para o byte 17 para buscar nos dados
      fseek(arqBin, 17, SEEK_SET);

      int naoEhInexistente = 0; // para ver se o registro foi printado ou não

      // fazer busca até o final do arquivo
      while (check_eof(arqBin)){
        RegistroDado *r = ler_reg_dado_bin(arqBin);

        if (r == NULL) break; // caso falte memória

        // verificando se o registro está logicamente removido
        // se for removido, apenas ignora e continua
        if (r->removido == '1'){
          free_reg_dado(r);
          free(r);
          continue;
        }
        
        int achou = verificacao_filtros(r, nomesCampos, valoresCampos, quantPar);

        if (achou){
          imprimir_reg_dado(r);
          naoEhInexistente = 1;
        }

        // para verificar se a busca por cod deu certo
        int pararBusca = (filtroCod && r->codEstacao == codBuscado);

        free_reg_dado(r);
        free(r);

        if (pararBusca) break; // se foi encontrado pelo codEstacao e se é igual ao buscado, para
      }

      if (!naoEhInexistente) printf("Registro inexistente.\n");
    }
    
    if (i < quantBusca - 1) printf("\n"); // pula linha, menos na última
  }

  // dar free e close
  free(listaIndice);
  free(h);
  fclose(arqBin);
}
